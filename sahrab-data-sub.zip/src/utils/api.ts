// API Client helper for SAHRAB DATA SUB

const API_BASE = '/api';

function getAuthHeader(): Record<string, string> {
  const token = localStorage.getItem('sahrab_auth_token');
  return token ? { Authorization: `Bearer ${token}` } : {};
}

export async function apiRequest(endpoint: string, options: RequestInit = {}) {
  const headers = {
    'Content-Type': 'application/json',
    ...getAuthHeader(),
    ...(options.headers || {}),
  };

  const response = await fetch(`${API_BASE}${endpoint}`, {
    ...options,
    headers,
  });

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    const error: any = new Error(data.message || `Request failed with status ${response.status}`);
    error.status = response.status;
    error.code = data.code;
    error.data = data;
    error.requiredConfiguration = data.requiredConfiguration;
    error.serviceTitle = data.serviceTitle;
    throw error;
  }

  return data;
}

// Auth API
export const authApi = {
  login: (credentials: { email?: string; phone?: string; password: string }) =>
    apiRequest('/auth/login', { method: 'POST', body: JSON.stringify(credentials) }),

  register: (payload: { fullName: string; email: string; phone: string; password: string; pin?: string }) =>
    apiRequest('/auth/register', { method: 'POST', body: JSON.stringify(payload) }),

  getMe: () => apiRequest('/auth/me'),

  resetPassword: (payload: { email: string; newPassword: string }) =>
    apiRequest('/auth/reset-password', { method: 'POST', body: JSON.stringify(payload) }),
};

// Position Management API
export const positionApi = {
  getHierarchy: () => apiRequest('/positions/hierarchy'),

  getUsers: (params: { search?: string; position?: string; status?: string } = {}) => {
    const q = new URLSearchParams();
    if (params.search) q.append('search', params.search);
    if (params.position) q.append('position', params.position);
    if (params.status) q.append('status', params.status);
    return apiRequest(`/positions/users?${q.toString()}`);
  },

  getTeams: () => apiRequest('/positions/teams'),

  getHistory: (userId?: string) => {
    const q = userId ? `?userId=${encodeURIComponent(userId)}` : '';
    return apiRequest(`/positions/history${q}`);
  },

  assignPosition: (payload: {
    targetUserId: string;
    newPosition: string;
    assignedTeam?: string;
    stateRegion?: string;
    supervisorId?: string;
    supervisorName?: string;
    effectiveDate?: string;
    reason: string;
    confirmed: boolean;
  }) => apiRequest('/positions/assign', { method: 'POST', body: JSON.stringify(payload) }),
};

// KYC API
export const kycApi = {
  getStatus: () => apiRequest('/kyc/status'),
  getConfig: () => apiRequest('/kyc/config'),
  checkConfig: () => apiRequest('/kyc/check-config', { method: 'POST' }),
  verifyIdentifier: (payload: { method: 'BVN' | 'NIN'; identifier: string; consent: boolean }) =>
    apiRequest('/kyc/step1-verify-id', { method: 'POST', body: JSON.stringify(payload) }),
  submitFaceMatch: (payload: { selfieBase64: string; method?: string; maskedIdentifier?: string; verificationSessionId?: string }) =>
    apiRequest('/kyc/step2-face-match', { method: 'POST', body: JSON.stringify(payload) }),
  verifyIdentity: (payload: { nin?: string; bvn?: string; selfieBase64?: string; consent: boolean }) =>
    apiRequest('/kyc/verify', { method: 'POST', body: JSON.stringify(payload) }),
  skipVerification: () =>
    apiRequest('/kyc/skip', { method: 'POST' }),
};

// Wallet API
export const walletApi = {
  getBalance: () => apiRequest('/wallet/balance'),
  getTransactions: () => apiRequest('/wallet/transactions'),
  getVirtualAccounts: () => apiRequest('/wallet/virtual-accounts'),
  generateVirtualAccounts: () => apiRequest('/wallet/virtual-accounts/generate', { method: 'POST' }),
  verifyTransfer: (reference: string) =>
    apiRequest('/wallet/monnify/verify-transfer', { method: 'POST', body: JSON.stringify({ reference }) }),
  fundWallet: (amount: number) =>
    apiRequest('/wallet/fund', { method: 'POST', body: JSON.stringify({ amount }) }),
  withdraw: (payload: { amount: number; bankName: string; accountNumber: string; accountName: string }) =>
    apiRequest('/wallet/withdraw', { method: 'POST', body: JSON.stringify(payload) }),
};

// Data & Airtime API
export const dataApi = {
  getPlans: (network?: string) => {
    const q = network ? `?network=${encodeURIComponent(network)}` : '';
    return apiRequest(`/data/plans${q}`);
  },
  buyData: (payload: { planId: string; recipientPhone: string }) =>
    apiRequest('/data/buy-data', { method: 'POST', body: JSON.stringify(payload) }),
  buyAirtime: (payload: { network: string; recipientPhone: string; amount: number }) =>
    apiRequest('/data/buy-airtime', { method: 'POST', body: JSON.stringify(payload) }),
};

// Dashboard API
export const dashboardApi = {
  getStats: () => apiRequest('/dashboards/stats'),
};

// Global User Directory & Removal API
export const usersApi = {
  getDirectory: (params: {
    page?: number;
    limit?: number;
    search?: string;
    position?: string;
    team?: string;
    state?: string;
    status?: string;
    dateFrom?: string;
    dateTo?: string;
  } = {}) => {
    const q = new URLSearchParams();
    if (params.page) q.append('page', params.page.toString());
    if (params.limit) q.append('limit', params.limit.toString());
    if (params.search) q.append('search', params.search);
    if (params.position) q.append('position', params.position);
    if (params.team) q.append('team', params.team);
    if (params.state) q.append('state', params.state);
    if (params.status) q.append('status', params.status);
    if (params.dateFrom) q.append('dateFrom', params.dateFrom);
    if (params.dateTo) q.append('dateTo', params.dateTo);
    return apiRequest(`/users/directory?${q.toString()}`);
  },

  getFilterOptions: () => apiRequest('/users/filter-options'),

  deactivateUser: (userId: string, payload: { reason: string; confirmed: boolean }) =>
    apiRequest(`/users/${encodeURIComponent(userId)}/deactivate`, {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  reactivateUser: (userId: string, payload: { reason?: string } = {}) =>
    apiRequest(`/users/${encodeURIComponent(userId)}/reactivate`, {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
};

// CEO / Founder Executive API
export const ceoApi = {
  getOverview: () => apiRequest('/ceo/overview'),
  getFinancials: () => apiRequest('/ceo/financials'),
  getOrganization: () => apiRequest('/ceo/organization'),
  getPayroll: (status?: string) => {
    const q = status ? `?status=${encodeURIComponent(status)}` : '';
    return apiRequest(`/ceo/payroll${q}`);
  },
  approvePayroll: (payrollId: string, notes?: string) =>
    apiRequest(`/ceo/payroll/${encodeURIComponent(payrollId)}/approve`, {
      method: 'POST',
      body: JSON.stringify({ notes }),
    }),
  disbursePayroll: (payrollId: string, payload: { paymentReference: string; disbursementMethod?: string }) =>
    apiRequest(`/ceo/payroll/${encodeURIComponent(payrollId)}/disburse`, {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  getCustomers: (search?: string) => {
    const q = search ? `?search=${encodeURIComponent(search)}` : '';
    return apiRequest(`/ceo/customers${q}`);
  },
  revokeStaff: (staffId: string, reason?: string) =>
    apiRequest(`/ceo/staff/${encodeURIComponent(staffId)}/revoke`, {
      method: 'POST',
      body: JSON.stringify({ reason }),
    }),
  getAuditLogs: () => apiRequest('/ceo/audit'),
};


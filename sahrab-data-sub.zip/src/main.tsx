import React from 'react';
import ReactDOM from 'react-dom/client';
import { AppProvider } from './context/AppContext.tsx';
import { App } from './App.tsx';
import './index.css';

const rootElement = document.getElementById('root');

if (rootElement) {
  ReactDOM.createRoot(rootElement).render(
    <React.StrictMode>
      <AppProvider>
        <App />
      </AppProvider>
    </React.StrictMode>
  );
}

import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { query } from '../db.ts';

const JWT_SECRET = process.env.JWT_SECRET || 'sahrab-data-sub-secure-jwt-secret-key-2026';

export interface AuthenticatedUser {
  id: string;
  fullName: string;
  email: string;
  phone: string;
  role: string;
  position: 'FOUNDER_SUPER_ADMIN' | 'ADMIN' | 'STATE_MANAGER' | 'TEAM_LEADER' | 'AGENT' | 'CUSTOMER';
  assignedTeam?: string | null;
  supervisorId?: string | null;
  supervisorName?: string | null;
  stateRegion?: string | null;
  appointedAt?: string | null;
  status: string;
  walletBalance: string;
  commissionBalance: string;
  kycStatus: string;
}

declare global {
  namespace Express {
    interface Request {
      user?: AuthenticatedUser;
    }
  }
}

export const POSITION_RANK: Record<string, number> = {
  FOUNDER_SUPER_ADMIN: 1,
  ADMIN: 2,
  STATE_MANAGER: 3,
  TEAM_LEADER: 4,
  AGENT: 5,
  CUSTOMER: 6,
};

export async function requireAuth(req: Request, res: Response, next: NextFunction) {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ success: false, message: 'Authentication required. No token provided.' });
    }

    const token = authHeader.split(' ')[1];
    const decoded = jwt.verify(token, JWT_SECRET) as { id: string };

    const result = await query(
      `SELECT id, full_name, email, phone, role, position, assigned_team, supervisor_id, supervisor_name, state_region, appointed_at, status, wallet_balance, commission_balance, kyc_status 
       FROM users 
       WHERE id = $1`,
      [decoded.id]
    );

    if (result.rows.length === 0) {
      return res.status(401).json({ success: false, message: 'User account not found.' });
    }

    const userRow = result.rows[0];

    // Check if deactivated or suspended
    if (userRow.status === 'deactivated' || userRow.status === 'suspended') {
      return res.status(403).json({
        success: false,
        message: `Account is ${userRow.status}. Please contact SAHRAB administration.`
      });
    }

    req.user = {
      id: userRow.id,
      fullName: userRow.full_name,
      email: userRow.email,
      phone: userRow.phone,
      role: userRow.role,
      position: (userRow.position || 'CUSTOMER') as AuthenticatedUser['position'],
      assignedTeam: userRow.assigned_team,
      supervisorId: userRow.supervisor_id,
      supervisorName: userRow.supervisor_name,
      stateRegion: userRow.state_region,
      appointedAt: userRow.appointed_at,
      status: userRow.status,
      walletBalance: userRow.wallet_balance || '0.00',
      commissionBalance: userRow.commission_balance || '0.00',
      kycStatus: userRow.kyc_status || 'not_verified',
    };

    next();
  } catch (err: any) {
    return res.status(401).json({ success: false, message: 'Invalid or expired session token.' });
  }
}

export function requirePosition(allowedPositions: string[]) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.user) {
      return res.status(401).json({ success: false, message: 'Unauthorized. Please sign in.' });
    }

    const userPos = req.user.position || 'CUSTOMER';
    if (!allowedPositions.includes(userPos)) {
      return res.status(403).json({
        success: false,
        message: `Access denied. Position '${userPos}' is not authorized to perform this operation.`
      });
    }

    next();
  };
}
